#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# Script d'import des serveurs depuis multiiptv.conf
#

import os
import json
import re
from ServerConfig import CONFIG_PATH, DEFAULT_CONFIG, add_server, save_config

MULTI_IPTV_CONFIG = "/etc/enigma2/multiiptv.conf"

def parse_multiiptv_config():
    """
    Parse le fichier multiiptv.conf et retourne une liste de serveurs
    """
    if not os.path.exists(MULTI_IPTV_CONFIG):
        print("Fichier {} non trouvé".format(MULTI_IPTV_CONFIG))
        return []
    
    servers = []
    
    with open(MULTI_IPTV_CONFIG, "r") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            
            # Ignorer les commentaires et lignes vides
            if not line or line.startswith("#"):
                continue
            
            # Ignorer la section [settings]
            if line.startswith("[") and line.endswith("]"):
                continue
            
            # Ignorer les lignes de paramètres
            if "=" in line and not "|" in line:
                continue
            
            # Diviser par le séparateur "|"
            parts = [p.strip() for p in line.split("|")]
            
            if len(parts) < 3:
                print("Ligne {}: format invalide, ignorée".format(line_num))
                continue
            
            server_type = parts[0].lower()
            
            if server_type == "stalker":
                # Format: stalker | name | url | mac | enabled
                if len(parts) >= 5:
                    name = parts[1]
                    url = parts[2]
                    mac = parts[3].upper()  # MAC en majuscules
                    enabled = parts[4] == "1"
                    
                    if enabled:
                        server = {
                            "type": "stalker",
                            "name": name,
                            "url": url.rstrip("/"),
                            "mac": mac,
                            "timezone": "Europe/Paris",
                            "token": None,
                            "expires": None
                        }
                        servers.append(server)
                        print("✓ Importé Stalker: {} ({})".format(name, url))
                else:
                    print("Ligne {}: Stalker - nombre de champs incorrect ({}), attendu 5".format(line_num, len(parts)))
            
            elif server_type == "xtream":
                # Format possible 1: xtream | name | host | port | username | password | enabled
                # Format possible 2: xtream | name | http://host:port | username | password | enabled
                
                if len(parts) >= 6:
                    name = parts[1]
                    
                    # Vérifier si le champ host contient déjà http://
                    host_part = parts[2]
                    use_https = False
                    port = 80
                    
                    # Extraire host et port
                    if host_part.startswith("http://"):
                        # Format: http://host:port
                        match = re.match(r"http://([^:/]+)(?::(\d+))?", host_part)
                        if match:
                            host = match.group(1)
                            port = int(match.group(2)) if match.group(2) else 80
                    elif host_part.startswith("https://"):
                        match = re.match(r"https://([^:/]+)(?::(\d+))?", host_part)
                        if match:
                            host = match.group(1)
                            port = int(match.group(2)) if match.group(2) else 443
                            use_https = True
                    else:
                        # Format: host:port ou host
                        if ":" in host_part:
                            host, port = host_part.split(":")
                            port = int(port)
                        else:
                            host = host_part
                            port = 80
                    
                    # Déterminer les champs username/password selon la longueur
                    if len(parts) == 6:
                        # Format: type | name | host | username | password | enabled
                        username = parts[3]
                        password = parts[4]
                        enabled = parts[5] == "1"
                    elif len(parts) == 7:
                        # Format: type | name | host | port | username | password | enabled
                        # Le port a déjà été extrait du host, donc username est parts[4]
                        username = parts[4] if len(parts) > 4 else ""
                        password = parts[5] if len(parts) > 5 else ""
                        enabled = parts[6] == "1" if len(parts) > 6 else True
                    else:
                        # Format alternatif
                        username = parts[3] if len(parts) > 3 else ""
                        password = parts[4] if len(parts) > 4 else ""
                        enabled = parts[5] == "1" if len(parts) > 5 else True
                    
                    if enabled and username and password:
                        scheme = "https" if use_https else "http"
                        base_url = "{}://{}:{}".format(scheme, host, port)
                        
                        server = {
                            "type": "xtream",
                            "name": name,
                            "host": host,
                            "port": port,
                            "username": username,
                            "password": password,
                            "base_url": base_url,
                            "use_https": use_https
                        }
                        servers.append(server)
                        print("✓ Importé Xtream: {} ({})".format(name, base_url))
                else:
                    print("Ligne {}: Xtream - nombre de champs incorrect ({}), attendu 6 ou 7".format(line_num, len(parts)))
            
            else:
                print("Ligne {}: type de serveur inconnu '{}'".format(line_num, server_type))
    
    return servers

def import_servers():
    """
    Importe les serveurs depuis multiiptv.conf vers stb_union_servers.json
    """
    print("\n" + "="*50)
    print("Import des serveurs depuis multiiptv.conf")
    print("="*50)
    
    # Charger la configuration existante
    config = DEFAULT_CONFIG.copy()
    
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                config = json.load(f)
            print("\nConfiguration existante chargée depuis: {}".format(CONFIG_PATH))
        except Exception as e:
            print("Erreur lors du chargement de la config: {}".format(e))
    
    # Parser le fichier multiiptv.conf
    new_servers = parse_multiiptv_config()
    
    if not new_servers:
        print("\nAucun serveur trouvé dans le fichier.")
        return
    
    print("\n" + "-"*50)
    print("Serveurs trouvés: {} nouveaux serveurs".format(len(new_servers)))
    print("-"*50)
    
    # Ajouter chaque serveur
    added_count = 0
    for server in new_servers:
        # Vérifier si le serveur existe déjà
        existing = False
        for s in config.get("servers", []):
            if s.get("name") == server.get("name"):
                existing = True
                print("⚠ Serveur '{}' existe déjà, ignoré".format(server.get("name")))
                break
        
        if not existing:
            config = add_server(config, server)
            added_count += 1
    
    # Sauvegarder la configuration
    if save_config(config):
        print("\n" + "="*50)
        print("✓ Import terminé! {} nouveaux serveurs ajoutés.".format(added_count))
        print("Configuration sauvegardée dans: {}".format(CONFIG_PATH))
        print("="*50)
        
        # Afficher les serveurs importés
        if added_count > 0:
            print("\nServeurs importés:")
            for server in new_servers:
                if server.get("type") == "stalker":
                    print("  - [Stalker] {} : {}".format(server.get("name"), server.get("url")))
                else:
                    print("  - [Xtream] {} : {}@{}:{}".format(
                        server.get("name"), 
                        server.get("username"),
                        server.get("host"),
                        server.get("port")))
    else:
        print("\n✗ Erreur lors de la sauvegarde de la configuration!")

def main():
    import_servers()

if __name__ == "__main__":
    main()