#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Main Menu Screen (matches reference UI)
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.MultiContent import MultiContentEntryText, MultiContentEntryPixmapAlphaBlend
from Components.Pixmap import Pixmap
from Components.Button import Button
from Components.Sources.StaticText import StaticText
from enigma import eListboxPythonMultiContent, gFont, RT_HALIGN_LEFT, RT_VALIGN_CENTER
from Screens.MessageBox import MessageBox
from Tools.Directories import fileExists
from time import localtime, strftime
from twisted.internet.task import LoopingCall

from .ServerConfig import load_config, save_config, SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .ServersScreen import ServersScreen  # Pour la gestion des serveurs
from .BouqScreen import BouqScreen        # Pour les bouquets
from .SettingsScreen import SettingsScreen
from .ConnectScreen import ConnectScreen
from .PlayerScreen import PlayerScreen


class STB_UNION_Main(Screen):
    """
    Main menu - mirrors the reference image:
    - Title bar: STB_UNION E2
    - Server list in center
    - Bottom row: Settings | Servers | Connect
    - Date and Time display (top right)
    """

    skin = """
        <screen name="STB_UNION E2_Main" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#1a0099">

            <!-- Background image Menu1.png -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/Menu1.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>

            <!-- Date and Time Display (Top Right) -->
            <widget name="datetime" position="1600,60" size="300,50"
                    font="Regular;28" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>

            <!-- Server List Panel (Center) -->
            <widget name="server_list" position="740,280" size="460,460"
                    scrollbarMode="showOnDemand" zPosition="2"
                    backgroundColor="#0a0060" foregroundColor="#ffffff"
                    font="Regular;22" transparent="1" />

            <!-- Bottom Navigation Labels -->
            <widget name="bottom_settings" position="285,960" size="200,40"
                    font="Regular;30" foregroundColor="#ff0000"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_servers" position="870,960" size="200,40"
                    font="Regular;30" foregroundColor="#11de0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_connect" position="1460,960" size="200,40"
                    font="Regular;30" foregroundColor="#ccde0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>

            <!-- Focus indicator for bottom navigation -->
            <widget name="focus_indicator" position="35,1040" size="1830,30"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="4" transparent="1"/>

            <!-- Status/Hint Bar -->
            <widget name="status" position="660,190" size="580,60"
                    font="Regular;20" foregroundColor="#00ff40"
                    backgroundColor="transparent" halign="center"
                    zPosition="2" transparent="1"/>
        </screen>
    """

    MENU_SETTINGS = 0
    MENU_SERVERS  = 1
    MENU_CONNECT  = 2

    def __init__(self, session):
        Screen.__init__(self, session)

        self.config  = load_config()
        self._focus  = self.MENU_CONNECT   # default focus on Connect
        self._server = None
        self.current_server = None  # Currently selected server in the list
        
        # Timer for updating date/time
        self.update_timer = None

        self["datetime"]        = Label("")
        self["title"]           = Label("STB_UNION E2")
        self["info_bar"]        = Label("")
        
        # Server list only (no details panel)
        self["server_list"]     = MenuList([])
        self["status"]          = Label("Use UP/DOWN to navigate servers | GREEN: Servers Manager | YELLOW: Bouquets")
        
        # Bottom navigation labels
        self["bottom_settings"] = Label("SETTINGS")
        self["bottom_servers"]  = Label("SERVERS")
        self["bottom_connect"]  = Label("CONNECT")
        
        self["focus_indicator"] = Label("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok":     self.on_ok,
                "cancel": self.on_cancel,
                "left":   self.nav_left,
                "right":  self.nav_right,
                "up":     self.nav_up,
                "down":   self.nav_down,
                "red":    self.open_settings,
                "green":  self.open_servers,      # GREEN = SERVERS (gestion des serveurs)
                "yellow": self.open_bouquets,     # YELLOW = BOUQUETS (contenu)
            }, -1
        )

        self.onLayoutFinish.append(self._post_init)
        self.onClose.append(self._on_close)

    # ------------------------------------------------------------------
    # Date and Time Management

    def _update_datetime(self):
        """Update the date and time display with full year"""
        current_hour = strftime("%H", localtime())
        current_minute = strftime("%M", localtime())
        current_day = strftime("%d", localtime())
        current_month = strftime("%m", localtime())
        current_year = strftime("%Y", localtime())
        
        datetime_str = "{}:{}  |  {}/{}/{}".format(
            current_hour, current_minute,
            current_day, current_month, current_year
        )
        self["datetime"].setText(datetime_str)

    def _start_datetime_timer(self):
        """Start the timer to update date/time every minute"""
        self._update_datetime()
        self.update_timer = LoopingCall(self._update_datetime)
        self.update_timer.start(60, now=False)

    def _on_close(self):
        """Stop the timer when screen is closed"""
        if self.update_timer and self.update_timer.running:
            self.update_timer.stop()

    # ------------------------------------------------------------------
    # Server List Management

    def _get_last_server(self):
        """Get the last selected server"""
        name = self.config.get("last_server")
        for s in self.config.get("servers", []):
            if s.get("name") == name:
                return s
        servers = self.config.get("servers", [])
        return servers[0] if servers else None

    def _refresh_server_list(self):
        """Refresh the server list - displays all servers with type and ★ for active"""
        servers = self.config.get("servers", [])
        items = []
        
        if not servers:
            items.append(("No servers configured. Press GREEN to add a server.", None))
        else:
            for s in servers:
                server_type = s.get("type", "?").upper()
                server_name = s.get("name", "?")
                star = " ★" if s.get("name") == self.config.get("last_server") else ""
                items.append(("[{}] {}{}".format(server_type, server_name, star), s))
        
        self["server_list"].setList(items)
        
        # Update status message
        if servers:
            active_server = self.config.get("last_server", "None")
            if active_server != "None":
                self["status"].setText("Active server: {} | Total: {} servers\nUse UP/DOWN to navigate | GREEN: Manage ".format(
                    active_server, len(servers)))
            else:
                self["status"].setText("Total: {} servers\nUse UP/DOWN to navigate | GREEN: Manage".format(len(servers)))
        else:
            self["status"].setText("No servers configured.\nPress GREEN to add a server.")

    # ------------------------------------------------------------------
    # Navigation

    def nav_up(self):
        """Navigate up in server list"""
        current_index = self["server_list"].getCurrentIndex()
        if current_index > 0:
            self["server_list"].setCurrentIndex(current_index - 1)
            self._update_status_on_selection()

    def nav_down(self):
        """Navigate down in server list"""
        current_index = self["server_list"].getCurrentIndex()
        item_count = len(self["server_list"].list)
        if current_index < item_count - 1:
            self["server_list"].setCurrentIndex(current_index + 1)
            self._update_status_on_selection()

    def _update_status_on_selection(self):
        """Update status message when a server is selected"""
        sel = self["server_list"].getCurrent()
        if sel and sel[1] is not None:
            server = sel[1]
            server_name = server.get("name", "")
            server_type = server.get("type", "").upper()
            is_active = "★ ACTIVE" if server.get("name") == self.config.get("last_server") else "Inactive"
            self["status"].setText("Selected: {} [{}] - {}\nGREEN: Manage | YELLOW: Bouquets".format(
                server_name, server_type, is_active))
        elif sel and sel[1] is None:
            self["status"].setText("No servers configured.\nPress GREEN to add a server.")

    def nav_left(self):
        self._focus = (self._focus - 1) % 3
        self._update_bottom_labels()

    def nav_right(self):
        self._focus = (self._focus + 1) % 3
        self._update_bottom_labels()

    def _update_bottom_labels(self):
        """Update the bottom labels appearance based on focus"""
        if self._focus == self.MENU_SETTINGS:
            self["bottom_settings"].setText("▶ SETTINGS ◀")
            self["bottom_servers"].setText("SERVERS")
            self["bottom_connect"].setText("CONNECT")
            self["focus_indicator"].setText("Press OK or RED to open SETTINGS")
        elif self._focus == self.MENU_SERVERS:
            self["bottom_settings"].setText("SETTINGS")
            self["bottom_servers"].setText("▶ SERVERS ◀")
            self["bottom_connect"].setText("CONNECT")
            self["focus_indicator"].setText("Press OK or GREEN to open SERVER MANAGER")
        else:
            self["bottom_settings"].setText("SETTINGS")
            self["bottom_servers"].setText("SERVERS")
            self["bottom_connect"].setText("▶ CONNECT ◀")
            self["focus_indicator"].setText("Press OK or YELLOW to open BOUQUETS")

    def on_ok(self):
        if self._focus == self.MENU_SETTINGS:
            self.open_settings()
        elif self._focus == self.MENU_SERVERS:
            self.open_servers()
        else:
            self.open_bouquets()

    def on_cancel(self):
        self.close()

    # ------------------------------------------------------------------
    # Sub-screens

    def open_settings(self):
        """Open settings screen"""
        self.session.openWithCallback(
            self._on_settings_closed, SettingsScreen, self.config)

    def _on_settings_closed(self, updated_config=None):
        if updated_config:
            self.config = updated_config
            save_config(self.config)

    def open_servers(self):
        """Open servers management screen (ServersScreen)"""
        self.session.openWithCallback(
            self._on_servers_closed, ServersScreen, self.config)

    def _on_servers_closed(self, updated_config=None):
        if updated_config:
            self.config = updated_config
            save_config(self.config)
            self._server = self._get_last_server()
            self._refresh_server_list()
            self["info_bar"].setText(self._server_label())

    def open_bouquets(self):
        """Open bouquets screen with active server (BouqScreen)"""
        # First, update the active server from config
        self._server = self._get_last_server()
        
        if not self._server:
            self.session.open(MessageBox,
                "No server configured!\n\nPlease add a server first using SERVER MANAGER (GREEN button).",
                MessageBox.TYPE_ERROR, timeout=5)
            return
        
        # Update status to show connection attempt
        server_name = self._server.get("name", "Unknown")
        server_type = self._server.get("type", "unknown").upper()
        self["status"].setText("Opening bouquets for {} [{}]...".format(server_name, server_type))
        
        # Open BouqScreen with the active server AND config
        self.session.openWithCallback(
            self._on_bouquets_closed, BouqScreen, self.config, self._server)

    def _on_bouquets_closed(self, *args):
        """Called when BouqScreen is closed"""
        # Refresh status when returning from BouqScreen
        if self._server:
            self["status"].setText("Returned from bouquets.\nPress YELLOW to open again.")
        else:
            self._refresh_server_list()

    def _server_label(self):
        if self._server:
            t = self._server.get("type", "?").upper()
            n = self._server.get("name", "")
            return "[{}] {}".format(t, n)
        return "No Server Selected"

    def _post_init(self):
        self._server = self._get_last_server()
        self["info_bar"].setText(self._server_label())
        self._update_bottom_labels()
        self._start_datetime_timer()
        self._refresh_server_list()