#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2- Add Server Screens
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.config import (config, ConfigSubsection, ConfigText,
                                ConfigYesNo, ConfigInteger, getConfigListEntry)
from Components.ConfigList import ConfigListScreen
from .ServerConfig import make_stalker_server, make_xtream_server

# --------------------------------------------------------------------- #
#  Add Stalker Server                                                     #
# --------------------------------------------------------------------- #

class AddStalkerScreen(ConfigListScreen, Screen):
    skin = """
        <screen name="AddStalkerScreen" position="300,225" size="1320,600"
                title="Add Stalker Portal Server" backgroundColor="#0d006e">
            <widget name="config" position="30,30" size="1260,450"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;24"/>
            <widget name="hint" position="30,495" size="1260,75"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center"/>
        </screen>
    """

    def __init__(self, session, server=None):
        Screen.__init__(self, session)

        self.cfg = ConfigSubsection()
        
        # If editing an existing server, pre-populate fields
        if server:
            self.cfg.name     = ConfigText(default=server.get("name", "My Stalker Server"), fixed_size=False)
            self.cfg.url      = ConfigText(default=server.get("url", "http://"), fixed_size=False)
            self.cfg.mac      = ConfigText(default=server.get("mac", "00:1A:79:XX:XX:XX"), fixed_size=False)
            self.cfg.timezone = ConfigText(default=server.get("timezone", "Europe/Paris"), fixed_size=False)
        else:
            self.cfg.name     = ConfigText(default="My Stalker Server", fixed_size=False)
            self.cfg.url      = ConfigText(default="http://", fixed_size=False)
            self.cfg.mac      = ConfigText(default="00:1A:79:XX:XX:XX", fixed_size=False)
            self.cfg.timezone = ConfigText(default="Europe/Paris", fixed_size=False)

        list_entries = [
            getConfigListEntry("Server Name:", self.cfg.name),
            getConfigListEntry("Portal URL:", self.cfg.url),
            getConfigListEntry("MAC Address:", self.cfg.mac),
            getConfigListEntry("Timezone:", self.cfg.timezone),
        ]

        ConfigListScreen.__init__(self, list_entries, session=session)

        self["hint"]    = Label("OK = Save   |   CANCEL = Abort")
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {"ok": self.on_save, "cancel": self.on_cancel}, -1
        )

    def on_save(self):
        server = make_stalker_server(
            name     = self.cfg.name.value.strip(),
            url      = self.cfg.url.value.strip(),
            mac      = self.cfg.mac.value.strip(),
            timezone = self.cfg.timezone.value.strip()
        )
        if not server["name"] or not server["url"] or not server["mac"]:
            self["hint"].setText("Name, URL and MAC are required!")
            return
        self.close(server)

    def on_cancel(self):
        self.close(None)


# --------------------------------------------------------------------- #
#  Add Xtream Server                                                      #
# --------------------------------------------------------------------- #

class AddXtreamScreen(ConfigListScreen, Screen):
    skin = """
        <screen name="AddXtreamScreen" position="300,180" size="1320,690"
                title="Add Xtream Codes Server" backgroundColor="#0d006e">
            <widget name="config" position="30,30" size="1260,570"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;24"/>
            <widget name="hint" position="30,600" size="1260,75"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center"/>
        </screen>
    """

    def __init__(self, session, server=None):
        Screen.__init__(self, session)

        self.cfg = ConfigSubsection()
        
        # If editing an existing server, pre-populate fields
        if server:
            self.cfg.name     = ConfigText(default=server.get("name", "My Xtream Server"), fixed_size=False)
            self.cfg.host     = ConfigText(default=server.get("host", "example.com"), fixed_size=False)
            self.cfg.port     = ConfigInteger(default=int(server.get("port", 8080)), limits=(1, 65535))
            self.cfg.username = ConfigText(default=server.get("username", "user"), fixed_size=False)
            self.cfg.password = ConfigText(default=server.get("password", "pass"), fixed_size=False)
            self.cfg.https    = ConfigYesNo(default=server.get("use_https", False))
        else:
            self.cfg.name     = ConfigText(default="My Xtream Server", fixed_size=False)
            self.cfg.host     = ConfigText(default="example.com", fixed_size=False)
            self.cfg.port     = ConfigInteger(default=8080, limits=(1, 65535))
            self.cfg.username = ConfigText(default="user", fixed_size=False)
            self.cfg.password = ConfigText(default="pass", fixed_size=False)
            self.cfg.https    = ConfigYesNo(default=False)

        list_entries = [
            getConfigListEntry("Server Name:", self.cfg.name),
            getConfigListEntry("Host / IP:", self.cfg.host),
            getConfigListEntry("Port:", self.cfg.port),
            getConfigListEntry("Username:", self.cfg.username),
            getConfigListEntry("Password:", self.cfg.password),
            getConfigListEntry("Use HTTPS:", self.cfg.https),
        ]

        ConfigListScreen.__init__(self, list_entries, session=session)

        self["hint"]    = Label("OK = Save   |   CANCEL = Abort")
        self["actions"] = ActionMap(
            ["OkCancelActions"],
            {"ok": self.on_save, "cancel": self.on_cancel}, -1
        )

    def on_save(self):
        server = make_xtream_server(
            name      = self.cfg.name.value.strip(),
            host      = self.cfg.host.value.strip(),
            port      = self.cfg.port.value,
            username  = self.cfg.username.value.strip(),
            password  = self.cfg.password.value.strip(),
            use_https = self.cfg.https.value
        )
        if not server["name"] or not server["host"] or not server["username"]:
            self["hint"].setText("Name, Host and Username are required!")
            return
        self.close(server)

    def on_cancel(self):
        self.close(None)