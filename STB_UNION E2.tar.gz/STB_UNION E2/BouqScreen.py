#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Bouquets Screen
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .StalkerAPI import StalkerAPI
from .XtreamAPI import XtreamAPI
from .PlayerScreen import PlayerScreen


class BouqScreen(Screen):
    """
    Bouquets Screen - Display channel categories
    """

    skin = """
        <screen name="BouqScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#000000">
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/BLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>
            <widget name="server_name" position="100,200" size="420,80"
                    font="Regular;42" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="bouquet_list" position="728,180" size="460,525"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;22" zPosition="2" transparent="1"/>
            <widget name="status_line1" position="1300,180" size="580,40"
                    font="Regular;30" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center" 
                    zPosition="2" transparent="1"/>
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
            <widget name="bottom_Live_TV" position="280,980" size="200,40"
                    font="Regular;30" foregroundColor="#fffb00"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_VOD" position="860,980" size="200,40"
                    font="Regular;30" foregroundColor="#11de0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="bottom_SERIES" position="1440,980" size="200,40"
                    font="Regular;30" foregroundColor="#0004ff"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
            <widget name="focus_indicator" position="35,1040" size="1830,30"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="4" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config, server):
        Screen.__init__(self, session)
        self.session = session
        self.config = config
        self.server = server
        self.api = None
        self._bouquets = []
        self._error_timer = None

        self["server_name"] = Label("[{}] {}".format(
            server.get("type", "").upper(), server.get("name", "")))
        self["bouquet_list"] = MenuList([])
        self["status_line1"] = Label("Connecting...")
        self["hint_bar"] = Label("UP/DOWN=Navigate  OK=View channels  EXIT=Back")
        self["bottom_Live_TV"] = Label("LIVE TV")
        self["bottom_VOD"] = Label("VOD")
        self["bottom_SERIES"] = Label("SERIES")
        self["focus_indicator"] = Label("")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok":     self.on_play,
                "cancel": self.on_back,
                "up":     self.nav_up,
                "down":   self.nav_down,
                "yellow": self.on_live_tv,   # Yellow = LIVE TV
                "red":    self.on_back_to_main, # Red = Back to Main Menu
                "green":  self.on_vod,        # Green = VOD
                "blue":   self.on_series,     # Blue = SERIES     
            }, -1
        )

        self.onLayoutFinish.append(self._init_api)

    def nav_up(self):
        current_index = self["bouquet_list"].getCurrentIndex()
        if current_index > 0:
            self["bouquet_list"].setCurrentIndex(current_index - 1)
            self._update_status()

    def nav_down(self):
        current_index = self["bouquet_list"].getCurrentIndex()
        item_count = len(self["bouquet_list"].list)
        if current_index < item_count - 1:
            self["bouquet_list"].setCurrentIndex(current_index + 1)
            self._update_status()

    def _update_status(self):
        sel = self["bouquet_list"].getCurrent()
        if sel:
            self["status_line1"].setText("Selected: {}".format(sel[0]))

    def _show_error_deferred(self, msg):
        self["status_line1"].setText("ERROR")
        self._error_timer = eTimer()
        self._error_timer.callback.append(lambda: self._show_message_box(msg))
        self._error_timer.start(100, True)

    def _show_message_box(self, msg):
        self.session.open(MessageBox, "Connection Error:\n" + msg,
                          MessageBox.TYPE_ERROR, timeout=5)

    def _init_api(self):
        stype = self.server.get("type")
        try:
            if stype == SERVER_TYPE_STALKER:
                self.api = StalkerAPI(self.server,
                    timeout=self.config["settings"].get("timeout", 15))
                token = self.api.handshake()
                if not token:
                    self._show_error_deferred("Stalker handshake failed!")
                    return
                self.server["token"] = token
            else:
                self.api = XtreamAPI(self.server,
                    timeout=self.config["settings"].get("timeout", 15))
                info = self.api.get_account_info()
                if not info:
                    self._show_error_deferred("Xtream login failed!")
                    return
                exp = info.get("user_info", {}).get("exp_date", "?")
                self["status_line1"].setText("Account expires: {}".format(exp))
        except Exception as e:
            self._show_error_deferred(str(e))
            return

        self._load_bouquets()

    def _load_bouquets(self):
        self["status_line1"].setText("Loading bouquets...")
        self._bouquets = []
        
        try:
            if isinstance(self.api, StalkerAPI):
                raw = self.api.get_channel_genres()
                self._bouquets = [(g.get("title", "?"), g.get("id", "*")) for g in raw]
            else:
                raw = self.api.get_live_categories()
                self._bouquets = [(c.get("category_name", "?"), c.get("category_id")) for c in raw]
        except Exception as e:
            self._show_error_deferred(str(e))
            return

        if not self._bouquets:
            self._bouquets = [("No bouquets found", None)]
            
        self["bouquet_list"].setList([(b[0], b[1]) for b in self._bouquets])
        self["status_line1"].setText("{} bouquets loaded".format(len(self._bouquets)))

    def _load_channels_async(self, bouquet_name, bouquet_id, callback):
        """Load channels asynchronously to avoid UI freeze"""
        channels = []
        
        try:
            if isinstance(self.api, StalkerAPI):
                items, total, items_per_page = self.api.get_channel(genre=bouquet_id, page=1)
                channels = [(i.get("name", "?"), i) for i in items]
                
                if total > items_per_page:
                    page = 2
                    while True:
                        items, _, _ = self.api.get_channel(genre=bouquet_id, page=page)
                        if not items:
                            break
                        channels.extend([(i.get("name", "?"), i) for i in items])
                        if page * items_per_page >= total:
                            break
                        page += 1
            else:
                items = self.api.get_live_streams(bouquet_id)
                channels = [(i.get("name", "?"), i) for i in items]
        except Exception as e:
            callback(None, str(e))
            return
            
        callback(channels, None)

    def on_play(self):
        sel = self["bouquet_list"].getCurrent()
        if sel and sel[1] is not None:
            self._open_bouquet_content(sel)

    def _open_bouquet_content(self, item_tuple):
        bouquet_name, bouquet_id = item_tuple[0], item_tuple[1]
        
        self["status_line1"].setText("Loading channels for {}...".format(bouquet_name))
        
        from .channel import channelScreen
        
        channels = []
        
        try:
            if isinstance(self.api, StalkerAPI):
                all_items = []
                page = 1
                while True:
                    items, total, items_per_page = self.api.get_channel(genre=bouquet_id, page=page)
                    if not items:
                        break
                    all_items.extend(items)
                    self["status_line1"].setText("Loading... {}/{}".format(len(all_items), total))
                    if page * items_per_page >= total:
                        break
                    page += 1
                channels = [(i.get("name", "?"), i) for i in all_items]
            else:
                items = self.api.get_live_streams(bouquet_id)
                channels = [(i.get("name", "?"), i) for i in items]
        except Exception as e:
            self._show_error_deferred(str(e))
            return
            
        if not channels:
            self["status_line1"].setText("No channels found")
            return
        
        # Pass config to channelScreen
        self.session.open(channelScreen, self.config, self.server, bouquet_name, channels)

    def on_live_tv(self):
        """Yellow button - Open selected bouquet or first one for LIVE TV"""
        sel = self["bouquet_list"].getCurrent()
        if sel and sel[1] is not None:
            self._open_bouquet_content(sel)
        elif self._bouquets:
            self._open_bouquet_content(self._bouquets[0])

    def on_vod(self):
        """Green button - Open VOD Screen"""
        if self._error_timer:
            self._error_timer.stop()
        
        self["status_line1"].setText("Loading VOD...")
        
        try:
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                # Pour Xtream, charger la liste des VOD
                vod_list = self.api.get_vod_streams()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
                    
            elif stype == SERVER_TYPE_STALKER:
                # Pour Stalker, charger la liste des VOD
                vod_list, total = self.api.get_vod_list()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
            else:
                self._show_error_deferred("Unsupported server type for VOD")
                
        except Exception as e:
            print("[STB_UNION E2] Error loading VOD: {}".format(e))
            self._show_error_deferred("VOD load error: {}".format(str(e)))

    def on_series(self):
        """Blue button - Open Series Screen"""
        if self._error_timer:
            self._error_timer.stop()
        
        self["status_line1"].setText("Loading Series...")
        
        try:
            stype = self.server.get("type")
            
            if stype == SERVER_TYPE_XTREAM:
                # Pour Xtream, charger la liste des séries
                series_list = self.api.get_series()
                if series_list:
                    from .SeriesScreen import SeriesScreen
                    self.session.open(SeriesScreen, self.config, self.server, series_list)
                else:
                    self._show_error_deferred("No Series content found")
                    
            elif stype == SERVER_TYPE_STALKER:
                # Pour Stalker, charger la liste des séries
                series_list, total = self.api.get_series_list()
                if series_list:
                    from .SeriesScreen import SeriesScreen
                    self.session.open(SeriesScreen, self.config, self.server, series_list)
                else:
                    self._show_error_deferred("No Series content found")
            else:
                self._show_error_deferred("Unsupported server type for Series")
                
        except Exception as e:
            print("[STB_UNION E2] Error loading Series: {}".format(e))
            self._show_error_deferred("Series load error: {}".format(str(e)))

    def on_back_to_main(self):
        """Red button - Back to main menu"""
        if self._error_timer:
            self._error_timer.stop()
        from .STB_UNION_Main import STB_UNION_Main
        self.session.open(STB_UNION_Main)

    def on_back(self):
        """Exit button - Close screen"""
        if self._error_timer:
            self._error_timer.stop()
        self.close()