#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 Plugin for Enigma2
# Supports: Stalker Portal & Xtream Codes
# Version: 1.0.0
#

from Plugins.Plugin import PluginDescriptor
from .STB_UNION_Main import STB_UNION_Main

def main(session, **kwargs):
    session.open(STB_UNION_Main)

def Plugins(**kwargs):
    return [
        PluginDescriptor(
            name="STB_UNION E2",
            description="Stalker & Xtream Server Manager for Enigma2",
            where=PluginDescriptor.WHERE_PLUGINMENU,
            icon="icon.png",
            fnc=main
        ),
        PluginDescriptor(
            name="STB_UNION E2",
            description="Stalker & Xtream Server Manager for Enigma2",
            where=PluginDescriptor.WHERE_EXTENSIONSMENU,
            fnc=main
        ),
    ]