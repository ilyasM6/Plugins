#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - channel Screen
# Affiche les chaînes du bouquet avec 15 chaînes par page
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from enigma import eTimer

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .PlayerScreen import PlayerScreen


class channelScreen(Screen):
    """
    channel Screen - 15 chaînes par page, navigation par pages
    """

    PAGE_SIZE = 15

    skin = """
        <screen name="channelScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#000000">

            <!-- Background image -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/ChLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>

            <!-- Header: Nom du bouquet -->
            <widget name="bouquet_name" position="100,200" size="420,80"
                    font="Regular;36" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>

            <!-- Liste 15 chaînes visibles -->
            <widget name="channel_list" position="730,180" size="460,588"
                    scrollbarMode="showNever" backgroundColor="#0a0060"
                    foregroundColor="#ffffff" font="Regular;20"
                    itemHeight="35" zPosition="2" transparent="1"/>

            <!-- Indicateur de page -->
            <widget name="page_info" position="730,740" size="460,36"
                    font="Regular;20" foregroundColor="#00a6ff"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>

            <!-- Statut ligne 1 -->
            <widget name="status_line1" position="1300,200" size="580,40"
                    font="Regular;28" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>

            <!-- Statut ligne 2 -->
            <widget name="status_line2" position="1250,250" size="580,60"
                    font="Regular;22" foregroundColor="#10e02f"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="2" transparent="1"/>

            <!-- Barre de hints -->
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;20" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>

            <!-- Nouveaux boutons en bas -->
            <widget name="btn_live_tv" position="280,980" size="200,40"
                    font="Regular;30" foregroundColor="#fffb00"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
                    
            <widget name="btn_vod" position="860,980" size="200,40"
                    font="Regular;30" foregroundColor="#11de0d"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
                    
            <widget name="btn_series" position="1440,980" size="200,40"
                    font="Regular;30" foregroundColor="#0004ff"
                    backgroundColor="transparent" halign="center" valign="center"
                    zPosition="3" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config, server, bouquet_name, channels):
        Screen.__init__(self, session)
        self.session      = session
        self.config       = config
        self.server       = server
        self.bouquet_name = bouquet_name
        self._all_channels = channels
        self._current_page = 0
        self._total_pages  = max(1, -(-len(channels) // self.PAGE_SIZE))
        self._error_timer  = None
        self._api = None  # Cache API instance

        self["bouquet_name"] = Label(bouquet_name)
        self["channel_list"] = MenuList([])
        self["page_info"]    = Label("")
        self["status_line1"] = Label("")
        self["status_line2"] = Label("")
        self["hint_bar"]     = Label(
            "UP/DOWN=Channel  CH+/CH-=Page  OK=Play  RED=Back  GREEN=VOD  BLUE=Series  EXIT=Close")
        
        # Nouveaux boutons
        self["btn_live_tv"] = Label("LIVE TV")
        self["btn_vod"] = Label("VOD")
        self["btn_series"] = Label("SERIES")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ChannelSelectBaseActions", "ColorActions"],
            {
                "ok":          self.on_play,
                "cancel":      self.on_back,
                "up":          self.nav_up,
                "down":        self.nav_down,
                "nextBouquet": self.next_page,
                "prevBouquet": self.prev_page,
                "red":         self.on_red,      # RED = Retour aux bouquets
                "green":       self.on_vod,      # GREEN = VOD
                "blue":        self.on_series,   # BLUE = SERIES
            }, -1
        )

        self.onLayoutFinish.append(self._show_page)
        self._init_api()

    # ----------------------------------------------------------------
    # API Initialization

    def _init_api(self):
        """Initialize API cache"""
        stype = self.server.get("type")
        if stype == SERVER_TYPE_STALKER:
            from .StalkerAPI import StalkerAPI
            self._api = StalkerAPI(self.server,
                                   timeout=self.config["settings"].get("timeout", 15))
            if not self._api.token and self.server.get("token"):
                self._api.token = self.server.get("token")
        else:
            from .XtreamAPI import XtreamAPI
            self._api = XtreamAPI(self.server,
                                  timeout=self.config["settings"].get("timeout", 15))

    # ----------------------------------------------------------------
    # Pagination

    def _get_page_items(self, page):
        start = page * self.PAGE_SIZE
        end   = start + self.PAGE_SIZE
        return self._all_channels[start:end]

    def _show_page(self, select_index=0):
        items = self._get_page_items(self._current_page)
        self["channel_list"].setList([(ch[0], ch[1]) for ch in items])
        select_index = max(0, min(select_index, len(items) - 1))
        self["channel_list"].setCurrentIndex(select_index)
        self._update_status()
        self["page_info"].setText(
            "Page {}/{}  ({} channels)".format(
                self._current_page + 1,
                self._total_pages,
                len(self._all_channels)
            )
        )

    def next_page(self):
        if self._current_page < self._total_pages - 1:
            self._current_page += 1
            self._show_page(0)
        else:
            self._current_page = 0
            self._show_page(0)

    def prev_page(self):
        if self._current_page > 0:
            self._current_page -= 1
            self._show_page(0)
        else:
            self._current_page = self._total_pages - 1
            self._show_page(0)

    # ----------------------------------------------------------------
    # Navigation

    def nav_up(self):
        idx = self["channel_list"].getCurrentIndex()
        if idx > 0:
            self["channel_list"].setCurrentIndex(idx - 1)
            self._update_status()
        else:
            # Aller à la page précédente, dernier élément
            self.prev_page()
            last = len(self["channel_list"].list) - 1
            if last >= 0:
                self["channel_list"].setCurrentIndex(last)
                self._update_status()

    def nav_down(self):
        idx  = self["channel_list"].getCurrentIndex()
        last = len(self["channel_list"].list) - 1
        if idx < last:
            self["channel_list"].setCurrentIndex(idx + 1)
            self._update_status()
        else:
            # Aller à la page suivante, premier élément
            self.next_page()
            if len(self["channel_list"].list) > 0:
                self["channel_list"].setCurrentIndex(0)
                self._update_status()

    def _update_status(self):
        sel   = self["channel_list"].getCurrent()
        idx   = self["channel_list"].getCurrentIndex()
        total = len(self._all_channels)
        global_idx = self._current_page * self.PAGE_SIZE + idx + 1
        if sel:
            name = sel[0] if isinstance(sel, tuple) else str(sel)
            self["status_line1"].setText(name)
            self["status_line2"].setText("{} / {}".format(global_idx, total))

    # ----------------------------------------------------------------
    # Error handling

    def _show_error_deferred(self, msg):
        self["status_line1"].setText("ERROR")
        self["status_line2"].setText(msg[:50])  # Tronquer si trop long
        self._error_timer = eTimer()
        self._error_timer.callback.append(lambda: self._show_message_box(msg))
        self._error_timer.start(100, True)

    def _show_message_box(self, msg):
        self.session.open(MessageBox, "Error:\n" + msg,
                          MessageBox.TYPE_ERROR, timeout=5)

    # ----------------------------------------------------------------
    # Stream URL building

    def _build_stream_url(self, item):
        """Build stream URL using cached API"""
        stype = self.server.get("type")
        
        if stype == SERVER_TYPE_STALKER:
            cmd = item.get("cmd", "")
            if not cmd:
                cmd = item.get("url", item.get("stream_url", ""))
            
            if not cmd:
                return None
            
            url = self._api.create_live_link(cmd)
            if url and url.startswith("ffmpeg "):
                url = url.replace("ffmpeg ", "").strip()
            return url
            
        else:  # XTREAM
            host = self.server.get("host", "").rstrip("/")
            port = self.server.get("port", 8080)
            
            if self.server.get("use_https", False):
                base_url = "https://{}:{}".format(host, port)
            else:
                base_url = "http://{}:{}".format(host, port)
            
            username = self.server.get("username", "")
            password = self.server.get("password", "")
            stream_id = item.get("stream_id", "")
            if not stream_id:
                stream_id = item.get("id", "")
            ext = item.get("container_extension", "ts")
            
            if not stream_id:
                return None
            
            return "{}/live/{}/{}/{}.{}".format(
                base_url, username, password, stream_id, ext)

    # ----------------------------------------------------------------
    # Playback

    def on_play(self):
        """Play selected channel"""
        sel = self["channel_list"].getCurrent()
        if not sel or sel[1] is None:
            return

        channel_name, item = sel[0], sel[1]
        self["status_line1"].setText("Loading: {}".format(channel_name))
        self["status_line2"].setText("Please wait...")

        try:
            stream_url = self._build_stream_url(item)
            
            if not stream_url:
                self._show_error_deferred("URL not found for: {}".format(channel_name))
                return
            
            # Clean URL
            if stream_url.startswith("ffmpeg "):
                stream_url = stream_url.replace("ffmpeg ", "").strip()
            
            # Check URL format
            if not (stream_url.startswith("http://") or 
                    stream_url.startswith("https://") or 
                    stream_url.startswith("rtsp://") or 
                    stream_url.startswith("rtmp://")):
                self._show_error_deferred("Unsupported format: {}".format(stream_url[:50]))
                return
                
        except Exception as e:
            self._show_error_deferred(str(e))
            return

        # Pass config to PlayerScreen
        self.session.open(PlayerScreen, stream_url, channel_name, "", self.config)

    # ----------------------------------------------------------------
    # Navigation actions

    def on_red(self):
        """Red button - Back to bouquets"""
        if self._error_timer:
            self._error_timer.stop()
        from .BouqScreen import BouqScreen
        self.session.open(BouqScreen, self.config, self.server)

    def on_vod(self):
        """Green button - Open VOD"""
        if self._error_timer:
            self._error_timer.stop()
        
        self["status_line1"].setText("Loading VOD...")
        
        try:
            if self.server.get("type") == SERVER_TYPE_XTREAM:
                vod_list = self._api.get_vod_streams()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
            elif self.server.get("type") == SERVER_TYPE_STALKER:
                vod_list, total = self._api.get_vod_list()
                if vod_list:
                    from .VodScreen import VodScreen
                    self.session.open(VodScreen, self.config, self.server, vod_list)
                else:
                    self._show_error_deferred("No VOD content found")
            else:
                self._show_error_deferred("Unsupported server type for VOD")
        except Exception as e:
            print("[STB_UNION E2] Error loading VOD: {}".format(e))
            self._show_error_deferred("VOD load error: {}".format(str(e)))

    def on_series(self):
        """Blue button - Open Series"""
        if self._error_timer:
            self._error_timer.stop()
        
        self["status_line1"].setText("Loading Series...")
        
        try:
            if self.server.get("type") == SERVER_TYPE_XTREAM:
                series_list = self._api.get_series()
                if series_list:
                    from .SeriesScreen import SeriesScreen
                    self.session.open(SeriesScreen, self.config, self.server, series_list)
                else:
                    self._show_error_deferred("No Series content found")
            elif self.server.get("type") == SERVER_TYPE_STALKER:
                series_list, total = self._api.get_series_list()
                if series_list:
                    from .SeriesScreen import SeriesScreen
                    self.session.open(SeriesScreen, self.config, self.server, series_list)
                else:
                    self._show_error_deferred("No Series content found")
            else:
                self._show_error_deferred("Unsupported server type for Series")
        except Exception as e:
            print("[STB_UNION E2] Error loading Series: {}".format(e))
            self._show_error_deferred("Series load error: {}".format(str(e)))

    def on_back(self):
        if self._error_timer:
            self._error_timer.stop()
        self.close()