# STB_UNION E2 Plugin for Enigma2
# Manages Stalker Portal and Xtream Codes servers