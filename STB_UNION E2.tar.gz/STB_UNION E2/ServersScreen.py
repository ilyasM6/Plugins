#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Servers Management Screen with Custom UI
# Using Settings.png as background with 5 buttons
# Button mapping: ADD=GREEN, DELETE=RED, EDIT=YELLOW, SELECT=BLUE, EXIT=EXIT
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList
from Components.Pixmap import Pixmap
from Components.Button import Button
from enigma import eListboxPythonMultiContent

from .ServerConfig import (add_server, remove_server,
                            make_stalker_server, make_xtream_server,
                            SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM)
from .AddServerScreen import AddStalkerScreen, AddXtreamScreen


class ServersScreen(Screen):
    """
    Custom Servers Management Screen using Settings.png background
    Features:
    - Background image: Settings.png
    - 5 buttons: ADD (GREEN), DELETE (RED), EDIT (YELLOW), SELECT (BLUE), EXIT (EXIT)
    - Server list on left
    - Selected server details on right
    """

    skin = """
        <screen name="ServersScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#000000">

            <!-- Background image Settings.png -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/Settings.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>

            <!-- Server List Panel (left side) -->
            <widget name="server_list" position="180,280" size="580,620"
                    scrollbarMode="showOnDemand" zPosition="2"
                    backgroundColor="#0a0060" foregroundColor="#ffffff"
                    font="Regular;22" transparent="1"/>

            <!-- Server Details Panel (right side) -->
            <widget name="server_detail" position="880,280" size="860,500"
                    font="Regular;20" foregroundColor="#ffdd00"
                    backgroundColor="#0a0060" halign="left" valign="top"
                    zPosition="2" transparent="1"/>

            <!-- Button 1: ADD (GREEN) -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/btn_add.png"
                     position="280,920" size="180,80" zPosition="2"/>
            <widget name="btn_add_lbl" position="280,920" size="180,60"
                    font="bolt;30" foregroundColor="#0f0f0f"
                    backgroundColor="#2cb809" halign="center" valign="center"
                    zPosition="3" transparent="0"/>

            <!-- Button 2: DELETE (RED) -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/btn_delete.png"
                     position="500,920" size="180,80" zPosition="2"/>
            <widget name="btn_delete_lbl" position="500,920" size="180,60"
                    font="bolt;30" foregroundColor="#0f0f0f"
                    backgroundColor="#b80909" halign="center" valign="center"
                    zPosition="3" transparent="0"/>

            <!-- Button 3: EDIT (YELLOW) -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/btn_edit.png"
                     position="720,920" size="180,80" zPosition="2"/>
            <widget name="btn_edit_lbl" position="720,920" size="180,60"
                    font="bolt;30" foregroundColor="#0f0f0f"
                    backgroundColor="#e6ed1a" halign="center" valign="center"
                    zPosition="3" transparent="0"/>

            <!-- Button 4: SELECT (BLUE) -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/btn_select.png"
                     position="940,920" size="180,80" zPosition="2"/>
            <widget name="btn_select_lbl" position="940,920" size="180,60"
                    font="bolt;30" foregroundColor="#0f0f0f"
                    backgroundColor="#1a0dd1" halign="center" valign="center"
                    zPosition="3" transparent="0"/>

            <!-- Button 5: EXIT (EXIT) -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/btn_exit.png"
                     position="1160,920" size="180,80" zPosition="2"/>
            <widget name="btn_exit_lbl" position="1160,920" size="180,60"
                    font="bolt;30" foregroundColor="#0f0f0f"
                    backgroundColor="#0dd1b0" halign="center" valign="center"
                    zPosition="3" transparent="0"/>

            <!-- Title/Header -->
            <widget name="title" position="0,80" size="1920,80"
                    font="Regular;42" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center"
                    zPosition="2" transparent="1"/>

            <!-- Status/Hint Bar -->
            <widget name="status" position="180,220" size="1560,50"
                    font="Regular;18" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="left"
                    zPosition="2" transparent="1"/>

            <!-- Button Hint Bar -->
            <widget name="button_hint" position="180,1000" size="1560,40"
                    font="Regular;16" foregroundColor="#cccccc"
                    backgroundColor="transparent" halign="center"
                    zPosition="2" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config):
        Screen.__init__(self, session)
        self.config = config
        self.current_server = None

        # Create widgets
        self["title"] = Label("")
        self["server_list"] = MenuList([])
        self["server_detail"] = Label("")
        self["status"] = Label("Select a server to view details")
        self["button_hint"] = Label("GREEN: ADD  |  RED: DELETE  |  YELLOW: EDIT  |  BLUE: SELECT  |  EXIT: EXIT")
        
        # Button labels with proper formatting - textes centrés sur les boutons
        self["btn_add_lbl"] = Label("ADD")
        self["btn_delete_lbl"] = Label("DELETE")
        self["btn_edit_lbl"] = Label("EDIT")
        self["btn_select_lbl"] = Label("SELECT")
        self["btn_exit_lbl"] = Label("EXIT")

        # Action mappings with correct color buttons
        self["actions"] = ActionMap(
            ["OkCancelActions", "ColorActions", "DirectionActions"],
            {
                "ok": self.on_select_server,
                "cancel": self.on_exit,
                "up": self.nav_up,
                "down": self.nav_down,
                # Color button mappings
                "green": self.on_add,      # GREEN = ADD
                "red": self.on_delete,     # RED = DELETE
                "yellow": self.on_edit,    # YELLOW = EDIT
                "blue": self.on_select,    # BLUE = SELECT
            }, -1
        )

        # Initialize list
        self.onLayoutFinish.append(self._refresh_list)

    # ------------------------------------------------------------------
    # Navigation

    def nav_up(self):
        """Navigate up in server list"""
        current_index = self["server_list"].getCurrentIndex()
        if current_index > 0:
            self["server_list"].setCurrentIndex(current_index - 1)
            self.on_select_server()

    def nav_down(self):
        """Navigate down in server list"""
        current_index = self["server_list"].getCurrentIndex()
        item_count = len(self["server_list"].list)
        if current_index < item_count - 1:
            self["server_list"].setCurrentIndex(current_index + 1)
            self.on_select_server()

    # ------------------------------------------------------------------
    # List Management

    def _refresh_list(self):
        """Refresh the server list"""
        servers = self.config.get("servers", [])
        items = []
        
        for s in servers:
            server_type = s.get("type", "?").upper()
            server_name = s.get("name", "?")
            star = " <<< ★" if s.get("name") == self.config.get("last_server") else ""
            items.append(("[{}] {}{}".format(server_type, server_name, star), s))
        
        self["server_list"].setList(items)
        
        # Update details if a server was selected
        if self.current_server:
            self._update_detail()
        elif items:
            # Auto-select first server if none selected
            self["server_list"].setCurrentIndex(0)
            self.current_server = items[0][1]
            self._update_detail()
        else:
            self["server_detail"].setText("╔══════════════════════════════════════╗\n"
                                         "║     NO SERVERS CONFIGURED           ║\n"
                                         "╠══════════════════════════════════════╣\n"
                                         "║                                      ║\n"
                                         "║  Press GREEN button (ADD)            ║\n"
                                         "║  to add a new server                 ║\n"
                                         "║                                      ║\n"
                                         "╚══════════════════════════════════════╝")
            self["status"].setText("No servers configured. Press GREEN to add a server.")

    def _update_detail(self):
        """Update the server details panel with your custom formatting"""
        if not self.current_server:
            self["server_detail"].setText("No server selected.")
            return
            
        s = self.current_server
        lines = []
        
        # Header with title
        lines.append("              ")
        lines.append("                                                  SERVER INFORMATION ")
        lines.append("          ")
        lines.append("")
        
        # Server details
        lines.append("                              Name:   {}".format(s.get("name", "N/A")))
        lines.append("                              Type:   {}".format(s.get("type", "").upper()))
        lines.append("")
        
        if s.get("type") == SERVER_TYPE_STALKER:
            lines.append("                      STALKER PORTAL ")
            lines.append("  ")
            lines.append("                          URL:    {}".format(s.get("url", "N/A")))
            lines.append("                          MAC:    {}".format(s.get("mac", "N/A")))
            lines.append("                          TZ:     {}".format(s.get("timezone", "Europe/Paris")))
            lines.append("  ")
            lines.append("  ")
        else:
            lines.append("                      XTREAM CODES ")
            lines.append("  ")
            lines.append("                          Host:    {}".format(s.get("host", "N/A")))
            lines.append("                          Port:    {}".format(s.get("port", "N/A")))
            lines.append("                          User:    {}".format(s.get("username", "N/A")))
            lines.append("                          Pass:    {}".format("*" * min(len(s.get("password", "")), 8)))
            lines.append("                          HTTPS:   {}".format("Yes" if s.get("use_https") else "No"))
            lines.append("  ")
            lines.append("")
        
        # Status indicator
        if s.get("name") == self.config.get("last_server"):
            lines.append("")
            lines.append("                        <<< ★ ACTIVE SERVER ★")
        
        lines.append("")
        lines.append("")
        
        self["server_detail"].setText("\n".join(lines))
        
        # Update status
        server_status = "<<< ★ ACTIVE" if s.get("name") == self.config.get("last_server") else "Inactive"
        self["status"].setText("Selected: {} [{}] - {}".format(
            s.get("name", ""), 
            s.get("type", "").upper(),
            server_status))

    # ------------------------------------------------------------------
    # Button Actions (with new color mapping)

    def on_add(self):
        """ADD button (GREEN) - Add a new server"""
        # Create a choice menu for server type
        from Screens.ChoiceBox import ChoiceBox
        
        choices = [
            ("Stalker Portal (MAC-based)", "stalker"),
            ("Xtream Codes (Username/Password)", "xtream")
        ]
        
        self.session.openWithCallback(
            self._on_server_type_selected,
            ChoiceBox,
            title="Select Server Type",
            list=choices
        )
    
    def _on_server_type_selected(self, choice):
        """Callback after server type selection"""
        if choice:
            server_type = choice[1]
            if server_type == "stalker":
                self.session.openWithCallback(
                    self._on_server_added, AddStalkerScreen)
            else:
                self.session.openWithCallback(
                    self._on_server_added, AddXtreamScreen)

    def _on_server_added(self, server=None):
        """Callback after adding a server"""
        if server:
            self.config = add_server(self.config, server)
            self._refresh_list()
            self["status"].setText("✓ Server '{}' added successfully!".format(server.get("name", "")))
        else:
            self["status"].setText("Server addition cancelled.")

    def on_delete(self):
        """DELETE button (RED) - Delete the selected server"""
        if not self.current_server:
            self["status"].setText("⚠ Please select a server first!")
            return
            
        name = self.current_server.get("name", "")
        self.session.openWithCallback(
            lambda r: self._confirm_delete(r, name),
            MessageBox,
            "Delete server '{}'?\n\nThis action cannot be undone!".format(name),
            MessageBox.TYPE_YESNO
        )

    def _confirm_delete(self, confirmed, name):
        """Confirm deletion"""
        if confirmed:
            self.config = remove_server(self.config, name)
            self.current_server = None
            self._refresh_list()
            self["status"].setText("✓ Server '{}' deleted successfully.".format(name))
        else:
            self["status"].setText("Server deletion cancelled.")

    def on_edit(self):
        """EDIT button (YELLOW) - Edit the selected server"""
        if not self.current_server:
            self["status"].setText("⚠ Please select a server first!")
            return
            
        server_type = self.current_server.get("type")
        self["status"].setText("Editing server: {}".format(self.current_server.get("name", "")))
        
        if server_type == SERVER_TYPE_STALKER:
            self.session.openWithCallback(
                self._on_server_edited, AddStalkerScreen, self.current_server)
        else:
            self.session.openWithCallback(
                self._on_server_edited, AddXtreamScreen, self.current_server)

    def _on_server_edited(self, server=None):
        """Callback after editing a server"""
        if server:
            # Remove old server and add updated one
            old_name = self.current_server.get("name", "")
            self.config = remove_server(self.config, old_name)
            self.config = add_server(self.config, server)
            self.current_server = server
            self._refresh_list()
            self["status"].setText("✓ Server '{}' updated successfully!".format(server.get("name", "")))
        else:
            self["status"].setText("Server edit cancelled.")

    def on_select(self):
        """SELECT button (BLUE) - Select the current server as active"""
        if not self.current_server:
            self["status"].setText("⚠ Please select a server first!")
            return
            
        server_name = self.current_server.get("name", "")
        self.config["last_server"] = server_name
        self._refresh_list()
        self["status"].setText("✓ Server '{}' selected as active!".format(server_name))

    def on_select_server(self):
        """Select a server from the list (OK button)"""
        sel = self["server_list"].getCurrent()
        if sel:
            self.current_server = sel[1]
            self._update_detail()

    def on_exit(self):
        """EXIT button (EXIT) - Return to main menu"""
        self.close(self.config)