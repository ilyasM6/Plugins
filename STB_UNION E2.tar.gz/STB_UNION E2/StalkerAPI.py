#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Stalker Portal API Handler (Python 3)
#

import urllib.request
import urllib.parse
import urllib.error
import json


class StalkerAPI:
    """Handles all Stalker Portal protocol communication."""

    def __init__(self, server_config, timeout=15):
        self.base_url = server_config.get("url", "").rstrip("/")
        self.mac      = server_config.get("mac", "")
        self.timezone = server_config.get("timezone", "Europe/Paris")
        self.timeout  = timeout
        self.token    = server_config.get("token") or ""
        self.cookies  = "mac={}; stb_lang=en; timezone={}".format(self.mac, self.timezone)

    def _headers(self):
        return {
            "User-Agent":   "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3",
            "Accept":       "application/json",
            "X-User-Agent": "Model: MAG250; Link: WiFi",
            "Cookie":       self.cookies,
            "Referer":      self.base_url + "/c/",
        }

    def _get(self, url):
        req = urllib.request.Request(url, headers=self._headers())
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw.decode("utf-8", errors="replace"))
        except urllib.error.HTTPError as e:
            print("[StalkerAPI] HTTP Error:", e.code, url)
        except Exception as e:
            print("[StalkerAPI] Error:", e, url)
        return None

    # ------------------------------------------------------------------
    # Authentication

    def handshake(self):
        url  = self.base_url + "/portal.php?action=handshake&type=stb&token="
        data = self._get(url)
        if data and "js" in data:
            self.token = data["js"].get("token", "")
            return self.token
        return None

    # ------------------------------------------------------------------
    # Live TV

    def get_channel_genres(self):
        url  = self.base_url + "/portal.php?action=get_genres&type=itv&token=" + self.token
        data = self._get(url)
        if data and "js" in data:
            return data["js"]
        return []

    def get_live_genres(self):
        return self.get_channel_genres()

    def get_channel(self, genre="*", page=1):
        params = urllib.parse.urlencode({
            "action": "get_ordered_list", "type": "itv",
            "token": self.token, "genre": genre,
            "p": page, "JsHttpRequest": "1-xml",
        })
        data = self._get(self.base_url + "/portal.php?" + params)
        if data and "js" in data:
            js = data["js"]
            return (js.get("data", []),
                    int(js.get("total_items", 0)),
                    int(js.get("max_page_items", 14)))
        return [], 0, 14

    def get_live_channels(self, genre="*", page=1):
        return self.get_channel(genre, page)

    # ------------------------------------------------------------------
    # VOD

    def get_vod_categories(self):
        """Récupère les catégories VOD"""
        url = self.base_url + "/portal.php?action=get_genres&type=video&token=" + self.token
        data = self._get(url)
        if data and "js" in data:
            return data["js"]
        return []

    def get_vod(self, genre="*", page=1):
        """Récupère la liste des VODs"""
        params = urllib.parse.urlencode({
            "action": "get_ordered_list", "type": "video",
            "token": self.token, "genre": genre,
            "p": page, "JsHttpRequest": "1-xml",
        })
        data = self._get(self.base_url + "/portal.php?" + params)
        if data and "js" in data:
            js = data["js"]
            return (js.get("data", []),
                    int(js.get("total_items", 0)),
                    int(js.get("max_page_items", 14)))
        return [], 0, 14

    def get_vod_list(self, genre="*"):
        """Récupère TOUS les VODs (sans pagination pour compatibilité)"""
        all_items = []
        page = 1
        while True:
            items, total, items_per_page = self.get_vod(genre, page)
            if not items:
                break
            all_items.extend(items)
            if page * items_per_page >= total:
                break
            page += 1
        return all_items, len(all_items)

    # ------------------------------------------------------------------
    # Series

    def get_series_categories(self):
        """Récupère les catégories de séries"""
        # Stalker utilise souvent le même endpoint que VOD pour les séries
        # ou un endpoint spécifique selon la version
        url = self.base_url + "/portal.php?action=get_genres&type=series&token=" + self.token
        data = self._get(url)
        if data and "js" in data:
            return data["js"]
        # Fallback: retourner les catégories VOD
        return self.get_vod_categories()

    def get_series(self, genre="*", page=1):
        """Récupère la liste des séries"""
        params = urllib.parse.urlencode({
            "action": "get_ordered_list", "type": "series",
            "token": self.token, "genre": genre,
            "p": page, "JsHttpRequest": "1-xml",
        })
        data = self._get(self.base_url + "/portal.php?" + params)
        if data and "js" in data:
            js = data["js"]
            return (js.get("data", []),
                    int(js.get("total_items", 0)),
                    int(js.get("max_page_items", 14)))
        return [], 0, 14

    def get_series_list(self, genre="*"):
        """Récupère TOUTES les séries (sans pagination pour compatibilité)"""
        all_items = []
        page = 1
        while True:
            items, total, items_per_page = self.get_series(genre, page)
            if not items:
                break
            all_items.extend(items)
            if page * items_per_page >= total:
                break
            page += 1
        return all_items, len(all_items)

    # ------------------------------------------------------------------
    # Create links

    def create_link(self, cmd, media_type="itv"):
        """
        Crée un lien de stream
        media_type: itv (live), video (vod), series
        """
        params = urllib.parse.urlencode({
            "action": "create_link", "type": media_type,
            "token": self.token, "cmd": cmd, "JsHttpRequest": "1-xml",
        })
        data = self._get(self.base_url + "/portal.php?" + params)
        
        if data and "js" in data:
            raw_cmd = data["js"].get("cmd", "")
            
            # Nettoyer comme dans live.py
            if raw_cmd.startswith("ffmpeg "):
                raw_cmd = raw_cmd.replace("ffmpeg ", "").strip()
            
            return raw_cmd
        
        return ""

    def create_live_link(self, cmd):
        return self.create_link(cmd, "itv")

    def create_vod_link(self, cmd):
        return self.create_link(cmd, "video")

    def create_series_link(self, cmd):
        return self.create_link(cmd, "series")