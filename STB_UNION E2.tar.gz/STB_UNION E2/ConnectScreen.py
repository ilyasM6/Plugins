#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Connect Screen
# Browse Live TV, VOD, Series from Stalker or Xtream server
#

from Screens.Screen import Screen
from Screens.MessageBox import MessageBox
from Components.ActionMap import ActionMap
from Components.Label import Label
from Components.MenuList import MenuList

from .ServerConfig import SERVER_TYPE_STALKER, SERVER_TYPE_XTREAM
from .StalkerAPI import StalkerAPI
from .XtreamAPI import XtreamAPI
from .PlayerScreen import PlayerScreen

# ------------------------------------------------------------------ #

MODE_LIVE   = "live"
MODE_VOD    = "vod"
MODE_SERIES = "series"


class ConnectScreen(Screen):
    """
    Main content browser.
    Tab through Live TV / VOD / Series.
    Left panel = categories, right panel = items.
    """

    skin = """
        <screen name="ConnectScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="#0d006e">

            <!-- Background image tv1.png -->
            <ePixmap pixmap="/usr/lib/enigma2/python/Plugins/Extensions/STB_UNION E2/skin/ChLive.png"
                     position="0,0" size="1920,1080" zPosition="-1" transparent="1"/>

            <!-- Header -->
            <widget name="server_name" position="0,15" size="1920,75"
                    font="Regular;36" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>

            <!-- Mode tabs -->
            <widget name="tab_live"   position="75,105"  size="390,60"
                    font="Regular;24" foregroundColor="#ffffff"
                    backgroundColor="#003388" halign="center" zPosition="2"/>
            <widget name="tab_vod"    position="765,105" size="390,60"
                    font="Regular;24" foregroundColor="#ffffff"
                    backgroundColor="#003388" halign="center" zPosition="2"/>
            <widget name="tab_series" position="1455,105" size="390,60"
                    font="Regular;24" foregroundColor="#ffffff"
                    backgroundColor="#003388" halign="center" zPosition="2"/>

            <!-- Category list -->
            <widget name="cat_list" position="30,195" size="540,780"
                    scrollbarMode="showOnDemand" backgroundColor="#0a0060"
                    foregroundColor="#ccddff" font="Regular;22" zPosition="2"/>

            <!-- Item list -->
            <widget name="item_list" position="600,195" size="1290,720"
                    scrollbarMode="showOnDemand" backgroundColor="#060040"
                    foregroundColor="#ffffff" font="Regular;22" zPosition="2"/>

            <!-- Status / EPG info -->
            <widget name="status" position="600,930" size="1290,120"
                    font="Regular;20" foregroundColor="#aaccff"
                    backgroundColor="transparent" halign="left" valign="top" zPosition="2" transparent="1"/>

            <!-- Bottom hints -->
            <widget name="hint_bar" position="0,1042" size="1920,38"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="center" zPosition="2" transparent="1"/>
        </screen>
    """

    def __init__(self, session, config, server):
        Screen.__init__(self, session)
        self.config = config
        self.server = server
        self.api    = None
        self.mode   = MODE_LIVE
        self._cats  = []     # current category list [(label, id), ...]
        self._items = []     # current item list [(label, data), ...]
        self._focus = "cat"  # "cat" or "item"

        self["server_name"] = Label("[{}] {}".format(
            server.get("type","").upper(), server.get("name","")))
        self["tab_live"]    = Label("[ Live TV ]")
        self["tab_vod"]     = Label("[ VOD ]")
        self["tab_series"]  = Label("[ Series ]")
        self["cat_list"]    = MenuList([])
        self["item_list"]   = MenuList([])
        self["status"]      = Label("Connecting...")
        self["hint_bar"]    = Label(
            "RED=Live  GREEN=VOD  YELLOW=Series  OK=Play/Select  LEFT/RIGHT=Switch panel  EXIT=Back")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "ColorActions"],
            {
                "ok":     self.on_ok,
                "cancel": self.on_back,
                "left":   self.focus_cat,
                "right":  self.focus_item,
                "red":    lambda: self.switch_mode(MODE_LIVE),
                "green":  lambda: self.switch_mode(MODE_VOD),
                "yellow": lambda: self.switch_mode(MODE_SERIES),
            }, -1
        )

        self.onLayoutFinish.append(self._init_api)

    # ----------------------------------------------------------------

    def _init_api(self):
        stype = self.server.get("type")
        try:
            if stype == SERVER_TYPE_STALKER:
                self.api = StalkerAPI(self.server,
                    timeout=self.config["settings"].get("timeout", 15))
                token = self.api.handshake()
                if not token:
                    self._show_error("Stalker handshake failed!")
                    return
                # persist token
                self.server["token"] = token
            else:
                self.api = XtreamAPI(self.server,
                    timeout=self.config["settings"].get("timeout", 15))
                info = self.api.get_account_info()
                if not info:
                    self._show_error("Xtream login failed!")
                    return
                exp = info.get("user_info", {}).get("exp_date", "?")
                self["status"].setText("Expires: {}".format(exp))
        except Exception as e:
            self._show_error(str(e))
            return

        self.switch_mode(MODE_LIVE)

    def _show_error(self, msg):
        self["status"].setText("ERROR: " + msg)
        self.session.open(MessageBox, "Connection Error:\n" + msg,
                          MessageBox.TYPE_ERROR, timeout=5)

    # ----------------------------------------------------------------
    # Mode switching

    def switch_mode(self, mode):
        self.mode = mode
        self._update_tabs()
        self._load_categories()

    def _update_tabs(self):
        styles = {
            MODE_LIVE:   (">>> Live TV <<<", "[ VOD ]",    "[ Series ]"),
            MODE_VOD:    ("[ Live TV ]",     ">>> VOD <<<", "[ Series ]"),
            MODE_SERIES: ("[ Live TV ]",     "[ VOD ]",    ">>> Series <<<"),
        }
        live, vod, ser = styles.get(self.mode, ("[ Live TV ]","[ VOD ]","[ Series ]"))
        self["tab_live"].setText(live)
        self["tab_vod"].setText(vod)
        self["tab_series"].setText(ser)

    def _load_categories(self):
        self["status"].setText("Loading categories...")
        try:
            if isinstance(self.api, StalkerAPI):
                if self.mode == MODE_LIVE:
                    raw = self.api.get_live_genres()
                    self._cats = [("All", "*")] + [(g.get("title","?"), g.get("id","*")) for g in raw]
                elif self.mode == MODE_VOD:
                    raw = self.api.get_vod_categories()
                    self._cats = [("All", "*")] + [(g.get("title","?"), g.get("id","*")) for g in raw]
                else:
                    self._cats = [("All", "*")]
            else:
                if self.mode == MODE_LIVE:
                    raw = self.api.get_live_categories()
                elif self.mode == MODE_VOD:
                    raw = self.api.get_vod_categories()
                else:
                    raw = self.api.get_series_categories()
                self._cats = [("All", None)] + [
                    (c.get("category_name","?"), c.get("category_id")) for c in raw]
        except Exception as e:
            self._show_error(str(e))
            return

        self["cat_list"].setList([(c[0], c) for c in self._cats])
        self["status"].setText("{} categories loaded.".format(len(self._cats)))
        self._load_items()

    def _load_items(self, cat_id=None):
        self["status"].setText("Loading content...")
        try:
            if isinstance(self.api, StalkerAPI):
                if self.mode == MODE_LIVE:
                    items, total, _ = self.api.get_live_channels(genre=cat_id or "*")
                    self._items = [(i.get("name","?"), i) for i in items]
                elif self.mode == MODE_VOD:
                    items, total = self.api.get_vod_list()
                    self._items = [(i.get("name","?"), i) for i in items]
                else:
                    items, total = self.api.get_series_list()
                    self._items = [(i.get("name","?"), i) for i in items]
            else:
                if self.mode == MODE_LIVE:
                    items = self.api.get_live_streams(cat_id)
                    self._items = [(i.get("name","?"), i) for i in items]
                elif self.mode == MODE_VOD:
                    items = self.api.get_vod_streams(cat_id)
                    self._items = [(i.get("name","?"), i) for i in items]
                else:
                    items = self.api.get_series(cat_id)
                    self._items = [(i.get("name","?"), i) for i in items]
        except Exception as e:
            self._show_error(str(e))
            return

        self["item_list"].setList([(i[0], i[1]) for i in self._items])
        self["status"].setText("{} items loaded.".format(len(self._items)))

    # ----------------------------------------------------------------
    # Focus & Navigation

    def focus_cat(self):
        self._focus = "cat"
        self["status"].setText("Category panel active - OK to load")

    def focus_item(self):
        self._focus = "item"
        self["status"].setText("Content panel active - OK to play")

    def on_ok(self):
        if self._focus == "cat":
            sel = self["cat_list"].getCurrent()
            if sel:
                self._load_items(cat_id=sel[1][1])
            self._focus = "item"
        else:
            sel = self["item_list"].getCurrent()
            if sel:
                self._play_item(sel)

    def _play_item(self, item_tuple):
        label, data = item_tuple[0], item_tuple[1]
        url = None
        try:
            if isinstance(self.api, StalkerAPI):
                cmd = data.get("cmd", "")
                if self.mode == MODE_LIVE:
                    url = self.api.create_live_link(cmd)
                else:
                    url = self.api.create_vod_link(cmd)
                # Stalker often returns "ffmpeg <url>"
                if url and url.startswith("ffmpeg "):
                    url = url.split(" ", 1)[1]
            else:
                stream_id = data.get("stream_id") or data.get("series_id")
                if self.mode == MODE_LIVE:
                    url = self.api.live_stream_url(stream_id)
                elif self.mode == MODE_VOD:
                    ext = data.get("container_extension", "mp4")
                    url = self.api.vod_stream_url(stream_id, ext)
                else:
                    # Series - open episode picker (simplified: open info)
                    self["status"].setText("Series: select episode in next screen (TODO)")
                    return
        except Exception as e:
            self._show_error(str(e))
            return

        if not url:
            self["status"].setText("Could not resolve stream URL.")
            return

        # CORRECTION: PlayerScreen attend (session, url, title, user_agent)
        user_agent = self.config["settings"].get("user_agent", "")
        self.session.open(PlayerScreen, url, label, user_agent)

    def on_back(self):
        self.close()