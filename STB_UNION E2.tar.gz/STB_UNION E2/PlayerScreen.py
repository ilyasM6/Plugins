#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Player Screen
# Launches streams using Enigma2's built-in media player
# Support du lecteur configurable (4097, 5001, 5002)
#

from Screens.Screen import Screen
from Components.ActionMap import ActionMap
from Components.Label import Label
from enigma import eServiceReference, eTimer
import ssl
import urllib.request


class PlayerScreen(Screen):
    """
    Player Screen avec support du lecteur configurable
    Permet à l'utilisateur de choisir entre:
    - 4097: GStreamer (lecteur par défaut)
    - 5001: ExtePlayer3 (lecteur externe)
    - 5002: ServiceApp (nécessite l'installation de ServiceApp)
    """

    skin = """
        <screen name="PlayerScreen" position="0,0" size="1920,1080"
                flags="wfNoBorder" backgroundColor="transparent">
            <widget name="channel_name" position="30,960" size="1350,75"
                    font="Regular;32" foregroundColor="#ffdd00"
                    backgroundColor="transparent" halign="left" zPosition="2"/>
            <widget name="stream_url" position="30,1032" size="1860,42"
                    font="Regular;18" foregroundColor="#888888"
                    backgroundColor="transparent" halign="left" zPosition="2"/>
            <widget name="status" position="30,1080" size="1860,40"
                    font="Regular;20" foregroundColor="#ff0000"
                    backgroundColor="transparent" halign="center" zPosition="2"/>
        </screen>
    """

    # Dictionnaire des types de lecteurs
    PLAYER_TYPES = {
        "4097": {"name": "GStreamer", "description": "Lecteur par défaut d'Enigma2"},
        "5001": {"name": "ExtePlayer3", "description": "Lecteur externe, meilleure compatibilité"},
        "5002": {"name": "ServiceApp", "description": "Nécessite l'installation de ServiceApp"}
    }

    def __init__(self, session, url, title="", user_agent="", config=None):
        Screen.__init__(self, session)
        
        self.url = url
        self.title = title
        self.user_agent = user_agent
        self.config = config  # Configuration du plugin
        self.playing = False
        self._hide_timer = None
        self.player_type = self._get_player_type()

        self["channel_name"] = Label(title)
        self["stream_url"] = Label(url[:100] + "..." if len(url) > 100 else url)
        self["status"] = Label("Chargement du stream...")

        self["actions"] = ActionMap(
            ["OkCancelActions", "DirectionActions", "MoviePlayerActions"],
            {
                "ok": self.stop_and_close,
                "cancel": self.stop_and_close,
                "up": self.volume_up,
                "down": self.volume_down,
                "play": self.play_pause,
                "pause": self.play_pause,
                "exit": self.stop_and_close,
            }, -1
        )

        self.onLayoutFinish.append(self._start_playback)
        self.onClose.append(self._on_close)

    def _get_player_type(self):
        """Récupère le type de lecteur depuis la configuration"""
        try:
            if self.config and "settings" in self.config:
                player_type = self.config["settings"].get("player_type", "4097")
                # S'assurer que c'est une string valide
                if player_type in self.PLAYER_TYPES:
                    return player_type
        except:
            pass
        return "4097"  # Valeur par défaut

    def _get_player_info(self):
        """Retourne les informations du lecteur sélectionné"""
        return self.PLAYER_TYPES.get(self.player_type, self.PLAYER_TYPES["4097"])

    # ------------------------------------------------------------------
    # Contrôles

    def volume_up(self):
        """Augmenter le volume"""
        try:
            from enigma import eDVBVolumecontrol
            eDVBVolumecontrol.getInstance().volumeUp()
            self["status"].setText("Volume +")
            self._start_hide_timer()
        except:
            pass

    def volume_down(self):
        """Diminuer le volume"""
        try:
            from enigma import eDVBVolumecontrol
            eDVBVolumecontrol.getInstance().volumeDown()
            self["status"].setText("Volume -")
            self._start_hide_timer()
        except:
            pass

    def play_pause(self):
        """Play/Pause"""
        try:
            service = self.session.nav.getCurrentService()
            if service:
                service.pause()
                self["status"].setText("Pause")
                self._start_hide_timer()
        except:
            pass

    def _start_hide_timer(self):
        """Démarre le timer pour cacher le message de statut"""
        if self._hide_timer:
            self._hide_timer.stop()
        self._hide_timer = eTimer()
        self._hide_timer.callback.append(self._hide_status)
        self._hide_timer.start(2000, True)

    def _hide_status(self):
        """Cache le message de statut"""
        if self.playing:
            self["status"].setText("")

    # ------------------------------------------------------------------
    # Lecture avec le lecteur configurable

    def _start_playback(self):
        """Démarre la lecture avec le type de lecteur sélectionné"""
        try:
            player_info = self._get_player_info()
            print("[PlayerScreen] Starting playback: {}".format(self.title))
            print("[PlayerScreen] URL: {}".format(self.url))
            print("[PlayerScreen] Player type: {} ({})".format(self.player_type, player_info["name"]))
            
            # Nettoyer l'URL
            stream_url = self.url.strip()
            
            # Vérifier et nettoyer les commandes ffmpeg
            if stream_url.startswith("ffmpeg "):
                stream_url = stream_url.replace("ffmpeg ", "").strip()
                print("[PlayerScreen] Cleaned ffmpeg URL: {}".format(stream_url[:80]))
            
            # Vérifier le format de l'URL
            if not (stream_url.startswith("http://") or 
                    stream_url.startswith("https://") or 
                    stream_url.startswith("rtsp://") or 
                    stream_url.startswith("rtmp://")):
                self["status"].setText("❌ Format non supporté")
                print("[PlayerScreen] Unsupported URL format: {}".format(stream_url[:80]))
                return
            
            # Créer la référence de service avec le type de lecteur choisi
            # Format: PLAYER_TYPE://URL
            player_code = int(self.player_type)
            sref = eServiceReference(player_code, 0, stream_url)
            sref.setName(self.title)
            
            # Option audio
            try:
                sref.setData(0, 1)
            except:
                pass
            
            # Arrêter tout service en cours
            self.session.nav.stopService()
            
            # Démarrer le nouveau service
            self.session.nav.playService(sref)
            self.playing = True
            
            self["status"].setText("▶️ Lecture: {} (Lecteur: {})".format(self.title, player_info["name"]))
            self._start_hide_timer()
            
            print("[PlayerScreen] Playback started successfully with player {}".format(player_info["name"]))
            
        except Exception as e:
            print("[PlayerScreen] Error starting playback: {}".format(e))
            self["status"].setText("❌ Erreur: {}".format(str(e)[:30]))
            # Attendre puis fermer
            timer = eTimer()
            timer.callback.append(self.stop_and_close)
            timer.start(3000, True)

    def _on_close(self):
        """Nettoyage"""
        if self._hide_timer:
            self._hide_timer.stop()

    def stop_and_close(self):
        """Arrêter le service et fermer"""
        try:
            self.session.nav.stopService()
        except:
            pass
        self.playing = False
        self.close()

    def keyExit(self):
        self.stop_and_close()