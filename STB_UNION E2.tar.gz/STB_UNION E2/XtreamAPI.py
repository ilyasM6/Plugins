#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# STB_UNION E2 - Xtream Codes API Handler (Python 3)
#

import urllib.request
import urllib.parse
import urllib.error
import json


class XtreamAPI:
    """Handles Xtream Codes API protocol."""

    def __init__(self, server_config, timeout=15):
        self.base_url = server_config.get("base_url", "").rstrip("/")
        self.username = server_config.get("username", "")
        self.password = server_config.get("password", "")
        self.timeout  = timeout
        self._auth    = "username={}&password={}".format(
            urllib.parse.quote(self.username),
            urllib.parse.quote(self.password))

    def _get(self, url):
        try:
            req = urllib.request.Request(url)
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read()
                return json.loads(raw.decode("utf-8", errors="replace"))
        except urllib.error.HTTPError as e:
            print("[XtreamAPI] HTTP Error:", e.code, url)
        except Exception as e:
            print("[XtreamAPI] Error:", e, url)
        return None

    # ----- Account -----

    def get_account_info(self):
        url = "{}/player_api.php?{}".format(self.base_url, self._auth)
        return self._get(url)

    # ----- Live TV -----

    def get_live_categories(self):
        url  = "{}/player_api.php?{}&action=get_live_categories".format(self.base_url, self._auth)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def get_channel_categories(self):
        return self.get_live_categories()

    def get_live_streams(self, category_id=None):
        url = "{}/player_api.php?{}&action=get_live_streams".format(self.base_url, self._auth)
        if category_id:
            url += "&category_id={}".format(category_id)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def live_stream_url(self, stream_id, ext="ts"):
        return "{}/{}/{}/{}.{}".format(
            self.base_url, self.username, self.password, stream_id, ext)

    # ----- VOD -----

    def get_vod_categories(self):
        url  = "{}/player_api.php?{}&action=get_vod_categories".format(self.base_url, self._auth)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def get_vod_streams(self, category_id=None):
        url = "{}/player_api.php?{}&action=get_vod_streams".format(self.base_url, self._auth)
        if category_id:
            url += "&category_id={}".format(category_id)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def get_vod_info(self, vod_id):
        url = "{}/player_api.php?{}&action=get_vod_info&vod_id={}".format(
            self.base_url, self._auth, vod_id)
        return self._get(url)

    def vod_stream_url(self, stream_id, ext="mp4"):
        return "{}/movie/{}/{}/{}.{}".format(
            self.base_url, self.username, self.password, stream_id, ext)

    # ----- Series -----

    def get_series_categories(self):
        url  = "{}/player_api.php?{}&action=get_series_categories".format(self.base_url, self._auth)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def get_series(self, category_id=None):
        url = "{}/player_api.php?{}&action=get_series".format(self.base_url, self._auth)
        if category_id:
            url += "&category_id={}".format(category_id)
        data = self._get(url)
        return data if isinstance(data, list) else []

    def get_series_info(self, series_id):
        url = "{}/player_api.php?{}&action=get_series_info&series_id={}".format(
            self.base_url, self._auth, series_id)
        return self._get(url)

    def series_episode_url(self, stream_id, ext="mkv"):
        return "{}/series/{}/{}/{}.{}".format(
            self.base_url, self.username, self.password, stream_id, ext)

    # ----- M3U Export -----

    def get_m3u_url(self, output="m3u8"):
        return "{}/get.php?{}&type=m3u_plus&output={}".format(
            self.base_url, self._auth, output)